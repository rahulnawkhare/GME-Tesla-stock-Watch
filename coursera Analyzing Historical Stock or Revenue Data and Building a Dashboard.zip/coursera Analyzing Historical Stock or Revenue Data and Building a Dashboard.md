```python
#Analyzing Historical Stock/Revenue Data and Building a Dashboard
```


```python


#Question 1: Use yfinance to Extract Stock Data

#Reset the index, save, and display the first five rows of the tesla_data dataframe using the head function. 
#Upload a screenshot of the results and code from the beginning of Question 1 to the results below.

!pip install yfinance
import yfinance as yf
import pandas as pd

# Download Tesla stock data
tesla = yf.Ticker("TSLA")
tesla_data = tesla.history(period="max")

# Reset the index
tesla_data.reset_index(inplace=True)

# Save data to a CSV file
tesla_data.to_csv("tesla_stock.csv", index=False)

# Display the first 5 rows
print(tesla_data.head())
```

    Requirement already satisfied: yfinance in c:\users\administrator\anaconda3\lib\site-packages (0.2.54)
    Requirement already satisfied: pandas>=1.3.0 in c:\users\administrator\anaconda3\lib\site-packages (from yfinance) (2.2.2)
    Requirement already satisfied: numpy>=1.16.5 in c:\users\administrator\anaconda3\lib\site-packages (from yfinance) (1.26.4)
    Requirement already satisfied: requests>=2.31 in c:\users\administrator\anaconda3\lib\site-packages (from yfinance) (2.32.3)
    Requirement already satisfied: multitasking>=0.0.7 in c:\users\administrator\anaconda3\lib\site-packages (from yfinance) (0.0.11)
    Requirement already satisfied: platformdirs>=2.0.0 in c:\users\administrator\anaconda3\lib\site-packages (from yfinance) (3.10.0)
    Requirement already satisfied: pytz>=2022.5 in c:\users\administrator\anaconda3\lib\site-packages (from yfinance) (2024.1)
    Requirement already satisfied: frozendict>=2.3.4 in c:\users\administrator\anaconda3\lib\site-packages (from yfinance) (2.4.2)
    Requirement already satisfied: peewee>=3.16.2 in c:\users\administrator\anaconda3\lib\site-packages (from yfinance) (3.17.9)
    Requirement already satisfied: beautifulsoup4>=4.11.1 in c:\users\administrator\anaconda3\lib\site-packages (from yfinance) (4.12.3)
    Requirement already satisfied: soupsieve>1.2 in c:\users\administrator\anaconda3\lib\site-packages (from beautifulsoup4>=4.11.1->yfinance) (2.5)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\administrator\anaconda3\lib\site-packages (from pandas>=1.3.0->yfinance) (2.9.0.post0)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\administrator\anaconda3\lib\site-packages (from pandas>=1.3.0->yfinance) (2023.3)
    Requirement already satisfied: charset-normalizer<4,>=2 in c:\users\administrator\anaconda3\lib\site-packages (from requests>=2.31->yfinance) (3.3.2)
    Requirement already satisfied: idna<4,>=2.5 in c:\users\administrator\anaconda3\lib\site-packages (from requests>=2.31->yfinance) (3.7)
    Requirement already satisfied: urllib3<3,>=1.21.1 in c:\users\administrator\anaconda3\lib\site-packages (from requests>=2.31->yfinance) (2.2.3)
    Requirement already satisfied: certifi>=2017.4.17 in c:\users\administrator\anaconda3\lib\site-packages (from requests>=2.31->yfinance) (2024.8.30)
    Requirement already satisfied: six>=1.5 in c:\users\administrator\anaconda3\lib\site-packages (from python-dateutil>=2.8.2->pandas>=1.3.0->yfinance) (1.16.0)
                           Date      Open      High       Low     Close  \
    0 2010-06-29 00:00:00-04:00  1.266667  1.666667  1.169333  1.592667   
    1 2010-06-30 00:00:00-04:00  1.719333  2.028000  1.553333  1.588667   
    2 2010-07-01 00:00:00-04:00  1.666667  1.728000  1.351333  1.464000   
    3 2010-07-02 00:00:00-04:00  1.533333  1.540000  1.247333  1.280000   
    4 2010-07-06 00:00:00-04:00  1.333333  1.333333  1.055333  1.074000   
    
          Volume  Dividends  Stock Splits  
    0  281494500        0.0           0.0  
    1  257806500        0.0           0.0  
    2  123282000        0.0           0.0  
    3   77097000        0.0           0.0  
    4  103003500        0.0           0.0  
    


```python
pip install selenium webdriver-manager beautifulsoup4 pandas

```

    Collecting selenium
      Downloading selenium-4.29.0-py3-none-any.whl.metadata (7.1 kB)
    Collecting webdriver-manager
      Downloading webdriver_manager-4.0.2-py2.py3-none-any.whl.metadata (12 kB)
    Requirement already satisfied: beautifulsoup4 in c:\users\administrator\anaconda3\lib\site-packages (4.12.3)
    Requirement already satisfied: pandas in c:\users\administrator\anaconda3\lib\site-packages (2.2.2)
    Requirement already satisfied: urllib3<3,>=1.26 in c:\users\administrator\anaconda3\lib\site-packages (from urllib3[socks]<3,>=1.26->selenium) (2.2.3)
    Collecting trio~=0.17 (from selenium)
      Downloading trio-0.29.0-py3-none-any.whl.metadata (8.5 kB)
    Collecting trio-websocket~=0.9 (from selenium)
      Downloading trio_websocket-0.12.1-py3-none-any.whl.metadata (5.1 kB)
    Requirement already satisfied: certifi>=2021.10.8 in c:\users\administrator\anaconda3\lib\site-packages (from selenium) (2024.8.30)
    Requirement already satisfied: typing_extensions~=4.9 in c:\users\administrator\anaconda3\lib\site-packages (from selenium) (4.11.0)
    Requirement already satisfied: websocket-client~=1.8 in c:\users\administrator\anaconda3\lib\site-packages (from selenium) (1.8.0)
    Requirement already satisfied: requests in c:\users\administrator\anaconda3\lib\site-packages (from webdriver-manager) (2.32.3)
    Requirement already satisfied: python-dotenv in c:\users\administrator\anaconda3\lib\site-packages (from webdriver-manager) (0.21.0)
    Requirement already satisfied: packaging in c:\users\administrator\anaconda3\lib\site-packages (from webdriver-manager) (24.1)
    Requirement already satisfied: soupsieve>1.2 in c:\users\administrator\anaconda3\lib\site-packages (from beautifulsoup4) (2.5)
    Requirement already satisfied: numpy>=1.26.0 in c:\users\administrator\anaconda3\lib\site-packages (from pandas) (1.26.4)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\administrator\anaconda3\lib\site-packages (from pandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\administrator\anaconda3\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\administrator\anaconda3\lib\site-packages (from pandas) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\users\administrator\anaconda3\lib\site-packages (from python-dateutil>=2.8.2->pandas) (1.16.0)
    Collecting attrs>=23.2.0 (from trio~=0.17->selenium)
      Downloading attrs-25.1.0-py3-none-any.whl.metadata (10 kB)
    Requirement already satisfied: sortedcontainers in c:\users\administrator\anaconda3\lib\site-packages (from trio~=0.17->selenium) (2.4.0)
    Requirement already satisfied: idna in c:\users\administrator\anaconda3\lib\site-packages (from trio~=0.17->selenium) (3.7)
    Collecting outcome (from trio~=0.17->selenium)
      Downloading outcome-1.3.0.post0-py2.py3-none-any.whl.metadata (2.6 kB)
    Requirement already satisfied: sniffio>=1.3.0 in c:\users\administrator\anaconda3\lib\site-packages (from trio~=0.17->selenium) (1.3.0)
    Requirement already satisfied: cffi>=1.14 in c:\users\administrator\anaconda3\lib\site-packages (from trio~=0.17->selenium) (1.17.1)
    Collecting wsproto>=0.14 (from trio-websocket~=0.9->selenium)
      Downloading wsproto-1.2.0-py3-none-any.whl.metadata (5.6 kB)
    Requirement already satisfied: pysocks!=1.5.7,<2.0,>=1.5.6 in c:\users\administrator\anaconda3\lib\site-packages (from urllib3[socks]<3,>=1.26->selenium) (1.7.1)
    Requirement already satisfied: charset-normalizer<4,>=2 in c:\users\administrator\anaconda3\lib\site-packages (from requests->webdriver-manager) (3.3.2)
    Requirement already satisfied: pycparser in c:\users\administrator\anaconda3\lib\site-packages (from cffi>=1.14->trio~=0.17->selenium) (2.21)
    Requirement already satisfied: h11<1,>=0.9.0 in c:\users\administrator\anaconda3\lib\site-packages (from wsproto>=0.14->trio-websocket~=0.9->selenium) (0.14.0)
    Downloading selenium-4.29.0-py3-none-any.whl (9.5 MB)
       ---------------------------------------- 0.0/9.5 MB ? eta -:--:--
       - -------------------------------------- 0.3/9.5 MB ? eta -:--:--
       -- ------------------------------------- 0.5/9.5 MB 1.7 MB/s eta 0:00:06
       --- ------------------------------------ 0.8/9.5 MB 1.4 MB/s eta 0:00:07
       ---- ----------------------------------- 1.0/9.5 MB 1.4 MB/s eta 0:00:06
       ----- ---------------------------------- 1.3/9.5 MB 1.4 MB/s eta 0:00:06
       ------- -------------------------------- 1.8/9.5 MB 1.4 MB/s eta 0:00:06
       -------- ------------------------------- 2.1/9.5 MB 1.4 MB/s eta 0:00:06
       --------- ------------------------------ 2.4/9.5 MB 1.4 MB/s eta 0:00:05
       ---------- ----------------------------- 2.6/9.5 MB 1.4 MB/s eta 0:00:05
       ------------ --------------------------- 2.9/9.5 MB 1.4 MB/s eta 0:00:05
       ------------- -------------------------- 3.1/9.5 MB 1.4 MB/s eta 0:00:05
       -------------- ------------------------- 3.4/9.5 MB 1.4 MB/s eta 0:00:05
       --------------- ------------------------ 3.7/9.5 MB 1.4 MB/s eta 0:00:05
       ---------------- ----------------------- 3.9/9.5 MB 1.4 MB/s eta 0:00:05
       ----------------- ---------------------- 4.2/9.5 MB 1.4 MB/s eta 0:00:04
       ------------------- -------------------- 4.7/9.5 MB 1.4 MB/s eta 0:00:04
       -------------------- ------------------- 5.0/9.5 MB 1.4 MB/s eta 0:00:04
       -------------------- ------------------- 5.0/9.5 MB 1.4 MB/s eta 0:00:04
       -------------------- ------------------- 5.0/9.5 MB 1.4 MB/s eta 0:00:04
       --------------------- ------------------ 5.2/9.5 MB 1.2 MB/s eta 0:00:04
       --------------------- ------------------ 5.2/9.5 MB 1.2 MB/s eta 0:00:04
       --------------------- ------------------ 5.2/9.5 MB 1.2 MB/s eta 0:00:04
       ----------------------- ---------------- 5.5/9.5 MB 1.2 MB/s eta 0:00:04
       ------------------------ --------------- 5.8/9.5 MB 1.1 MB/s eta 0:00:04
       ------------------------- -------------- 6.0/9.5 MB 1.1 MB/s eta 0:00:04
       -------------------------- ------------- 6.3/9.5 MB 1.1 MB/s eta 0:00:03
       --------------------------- ------------ 6.6/9.5 MB 1.2 MB/s eta 0:00:03
       ---------------------------- ----------- 6.8/9.5 MB 1.2 MB/s eta 0:00:03
       ------------------------------ --------- 7.3/9.5 MB 1.2 MB/s eta 0:00:02
       ------------------------------- -------- 7.6/9.5 MB 1.2 MB/s eta 0:00:02
       -------------------------------- ------- 7.9/9.5 MB 1.2 MB/s eta 0:00:02
       ---------------------------------- ----- 8.1/9.5 MB 1.2 MB/s eta 0:00:02
       ----------------------------------- ---- 8.4/9.5 MB 1.2 MB/s eta 0:00:01
       ------------------------------------ --- 8.7/9.5 MB 1.2 MB/s eta 0:00:01
       ------------------------------------- -- 8.9/9.5 MB 1.2 MB/s eta 0:00:01
       -------------------------------------- - 9.2/9.5 MB 1.2 MB/s eta 0:00:01
       ---------------------------------------- 9.5/9.5 MB 1.2 MB/s eta 0:00:00
    Downloading webdriver_manager-4.0.2-py2.py3-none-any.whl (27 kB)
    Downloading trio-0.29.0-py3-none-any.whl (492 kB)
    Downloading trio_websocket-0.12.1-py3-none-any.whl (21 kB)
    Downloading attrs-25.1.0-py3-none-any.whl (63 kB)
    Downloading outcome-1.3.0.post0-py2.py3-none-any.whl (10 kB)
    Downloading wsproto-1.2.0-py3-none-any.whl (24 kB)
    Installing collected packages: wsproto, attrs, webdriver-manager, outcome, trio, trio-websocket, selenium
      Attempting uninstall: attrs
        Found existing installation: attrs 23.1.0
        Uninstalling attrs-23.1.0:
          Successfully uninstalled attrs-23.1.0
    Successfully installed attrs-25.1.0 outcome-1.3.0.post0 selenium-4.29.0 trio-0.29.0 trio-websocket-0.12.1 webdriver-manager-4.0.2 wsproto-1.2.0
    Note: you may need to restart the kernel to use updated packages.
    


```python
import selenium
print("Selenium is installed correctly!")

```

    Selenium is installed correctly!
    


```python
import selenium
print("Selenium is installed correctly!")
```

    Selenium is installed correctly!
    


```python
!pip install requests beautifulsoup4 pandas

```

    Requirement already satisfied: requests in c:\users\administrator\anaconda3\lib\site-packages (2.32.3)
    Requirement already satisfied: beautifulsoup4 in c:\users\administrator\anaconda3\lib\site-packages (4.12.3)
    Requirement already satisfied: pandas in c:\users\administrator\anaconda3\lib\site-packages (2.2.2)
    Requirement already satisfied: charset-normalizer<4,>=2 in c:\users\administrator\anaconda3\lib\site-packages (from requests) (3.3.2)
    Requirement already satisfied: idna<4,>=2.5 in c:\users\administrator\anaconda3\lib\site-packages (from requests) (3.7)
    Requirement already satisfied: urllib3<3,>=1.21.1 in c:\users\administrator\anaconda3\lib\site-packages (from requests) (2.2.3)
    Requirement already satisfied: certifi>=2017.4.17 in c:\users\administrator\anaconda3\lib\site-packages (from requests) (2024.8.30)
    Requirement already satisfied: soupsieve>1.2 in c:\users\administrator\anaconda3\lib\site-packages (from beautifulsoup4) (2.5)
    Requirement already satisfied: numpy>=1.26.0 in c:\users\administrator\anaconda3\lib\site-packages (from pandas) (1.26.4)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\administrator\anaconda3\lib\site-packages (from pandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\administrator\anaconda3\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\administrator\anaconda3\lib\site-packages (from pandas) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\users\administrator\anaconda3\lib\site-packages (from python-dateutil>=2.8.2->pandas) (1.16.0)
    


```python
#Question 2: Use Webscraping to Extract Tesla Revenue Data

#Display the last five rows of the tesla_revenue dataframe using the tail function. Upload a screenshot of the results.

import requests
import pandas as pd
from bs4 import BeautifulSoup

# Define the URL
url = "https://www.macrotrends.net/stocks/charts/TSLA/tesla/revenue"

# Send an HTTP request to fetch the page content
response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})

# Check if the request was successful
if response.status_code == 200:
    soup = BeautifulSoup(response.text, "html.parser")

    # Find all tables in the HTML content
    tables = soup.find_all("table")

    # Identify the correct revenue table using keywords
    revenue_table = None
    for table in tables:
        if "Tesla Quarterly Revenue" in table.text:
            revenue_table = table
            break

    # Extract table rows
    data = []
    if revenue_table:
        for row in revenue_table.find_all("tr")[1:]:  # Skip header row
            columns = row.find_all("td")
            if len(columns) == 2:
                date = columns[0].text.strip()
                revenue = columns[1].text.strip()
                data.append([date, revenue])

        # Create a Pandas DataFrame
        tesla_revenue = pd.DataFrame(data, columns=["Date", "Revenue"])

        # Display the last five rows
        print(tesla_revenue.tail())
    else:
        print("Revenue table not found.")
else:
    print("Failed to retrieve data, Status Code:", response.status_code)

```

              Date Revenue
    58  2010-06-30     $28
    59  2010-03-31     $21
    60  2009-12-31        
    61  2009-09-30     $46
    62  2009-06-30     $27
    


```python
#Question 3: Use yfinance to Extract Stock Data

#Reset the index, save, and display the first five rows of the gme_data dataframe using the head function. 
#Upload a screenshot of the results and code from the beginning of Question 1 to the results below.

import yfinance as yf
import pandas as pd

# Download GameStop stock data
gme_data = yf.download("GME", start="2010-01-01", end="2024-01-01")

# Reset the index to move the date column into the dataframe
gme_data.reset_index(inplace=True)

# Save the data to a CSV file (optional)
gme_data.to_csv("gme_stock_data.csv", index=False)

# Display the first five rows
print(gme_data.head())

```

    YF.download() has changed argument auto_adjust default to True
    

    [*********************100%***********************]  1 of 1 completed

    Price        Date     Close      High       Low      Open     Volume
    Ticker                  GME       GME       GME       GME        GME
    0      2010-01-04  3.854643  3.863059  3.703150  3.714933   26702800
    1      2010-01-05  3.959005  3.996037  3.854644  3.856327   21269600
    2      2010-01-06  4.044850  4.056633  3.908506  3.948904   21471200
    3      2010-01-07  3.443930  3.563441  3.268873  3.368184  164761200
    4      2010-01-08  3.415315  3.573540  3.405215  3.474228   47872400
    

    
    


```python
#Question 4: Use Webscraping to Extract GME Revenue Data

#Display the last five rows of the gme_revenue dataframe using the tail function. Upload a screenshot of the results.


#Method 1: Using requests and BeautifulSoup (Recommended)
import requests
from bs4 import BeautifulSoup
import pandas as pd

# Define the URL for GameStop revenue data
url = "https://www.macrotrends.net/stocks/charts/GME/gamestop/revenue"

# Send an HTTP request with headers to avoid blocking
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"}
response = requests.get(url, headers=headers)

# Check if the request was successful
if response.status_code != 200:
    print("Failed to retrieve data.")
else:
    soup = BeautifulSoup(response.text, "html.parser")

    # Find all tables in the HTML content
    tables = soup.find_all("table")

    # Identify the revenue table
    revenue_table = None
    for table in tables:
        if "GameStop Quarterly Revenue" in table.text:
            revenue_table = table
            break

    # Extract revenue data
    data = []
    if revenue_table:
        for row in revenue_table.find_all("tr")[1:]:  # Skip header row
            columns = row.find_all("td")
            if len(columns) == 2:
                date = columns[0].text.strip()
                revenue = columns[1].text.strip()
                data.append([date, revenue])

        # Create DataFrame
        gme_revenue = pd.DataFrame(data, columns=["Date", "Revenue"])
        
        # Display the last five rows
        print(gme_revenue.tail())

        # Save to CSV
        gme_revenue.to_csv("GME_Revenue.csv", index=False)
    else:
        print("Revenue table not found.")

```

              Date Revenue
    59  2010-01-31  $3,524
    60  2009-10-31  $1,835
    61  2009-07-31  $1,739
    62  2009-04-30  $1,981
    63  2009-01-31  $3,492
    


```python
#Question 5: Plot Tesla Stock Graph

#Use the make_graph function to graph the Tesla Stock Data, also provide a title for the graph.

Upload a screenshot of your results.

import yfinance as yf
import matplotlib.pyplot as plt

# Define a function to create a stock graph
def make_graph(data, title):
    plt.figure(figsize=(12, 6))
    plt.plot(data["Date"], data["Close"], label="Closing Price", color="blue")
    plt.xlabel("Date")
    plt.ylabel("Stock Price (USD)")
    plt.title(title)
    plt.legend()
    plt.xticks(rotation=45)
    plt.grid()
    plt.show()

# Download Tesla stock data
tesla_data = yf.download("TSLA", start="2010-01-01", end="2024-01-01")
tesla_data.reset_index(inplace=True)

# Plot the Tesla Stock Graph
make_graph(tesla_data, "Tesla Stock Price Over Time")

```

    [*********************100%***********************]  1 of 1 completed
    


    
![png](output_9_1.png)
    



```python
#Question 6: Plot GameStop Stock Graph

#Use the make_graph function to graph the GameStop Stock Data, also provide a title for the graph.

Upload a screenshot of your results.

import yfinance as yf
import matplotlib.pyplot as plt

# Download GameStop stock data
gme_data = yf.download("GME", start="2010-01-01", end="2024-01-01")

# Function to plot stock data
def make_graph(data, title):
    plt.figure(figsize=(10, 5))
    plt.plot(data.index, data["Close"], label="Closing Price", color="blue")
    plt.xlabel("Date")
    plt.ylabel("Stock Price (USD)")
    plt.title(title)
    plt.legend()
    plt.grid()
    plt.show()

# Plot GameStop stock data
make_graph(gme_data, "GameStop Stock Price Over Time")

```

    [*********************100%***********************]  1 of 1 completed
    


    
![png](output_10_1.png)
    



```python

```
